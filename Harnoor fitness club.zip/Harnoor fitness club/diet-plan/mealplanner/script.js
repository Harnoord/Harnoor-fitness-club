document.addEventListener('DOMContentLoaded', function () {
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const mealCalendar = document.getElementById('mealCalendar');
    const mealInputsContainer = document.getElementById('mealInputs');
    const saveButton = document.getElementById('saveButton');
    const generateListButton = document.getElementById('generateListButton');
    const clearButton = document.getElementById('clearButton');
    const shoppingListContainer = document.getElementById('shoppingListContainer');
    const mealPreferencesContainer = document.getElementById('mealPreferences');
  

  

for (let i = 0; i < 7; i++) {
 
    const dayContainer = document.createElement('div');
    dayContainer.classList.add('day-container');
  
    const label = document.createElement('label');
    label.setAttribute('for', `mealInput${i}`);
    label.textContent = `${daysOfWeek[i]}:`;
  

    const mealInput = document.createElement('input');
    mealInput.setAttribute('type', 'text');
    mealInput.setAttribute('id', `mealInput${i}`);
    mealInput.setAttribute('placeholder', 'Enter meal');
    mealInput.classList.add('meal-input');
  

    dayContainer.appendChild(label);
    dayContainer.appendChild(mealInput);
  

    mealInputsContainer.appendChild(dayContainer);
  }
  
  
    saveButton.addEventListener('click', saveMealPlan);

    generateListButton.addEventListener('click', generateShoppingList);
  
    clearButton.addEventListener('click', clearMealPlan);
  
   
    function saveMealPlan() {
      const mealPlan = [];
      const mealInputs = document.querySelectorAll('.meal-input');
  
      mealInputs.forEach((input, index) => {
        const day = daysOfWeek[index];
        const meal = input.value.trim();
        mealPlan.push({ day, meal });
      });
  
     
      console.log('Meal Plan:', mealPlan);
    }
  
  
    function generateShoppingList() {
      const mealInputs = document.querySelectorAll('.meal-input');
      const shoppingList = [];
  
      mealInputs.forEach(input => {
        const meal = input.value.trim();
        if (meal !== '') {
          shoppingList.push(meal);
        }
      });
  
   
      shoppingListContainer.innerHTML = `<strong>Shopping List:</strong><br>${shoppingList.join(', ')}`;
      shoppingListContainer.classList.remove('hidden');
    }
  
 
    function clearMealPlan() {
      const mealInputs = document.querySelectorAll('.meal-input');
      
      mealInputs.forEach(input => {
        input.value = '';
      });
  
      shoppingListContainer.innerHTML = '';
      shoppingListContainer.classList.add('hidden');
    }
  

    function addMealPreferences() {
 
      const preferences = ['Vegetarian', 'Vegan', 'Gluten-Free', 'Low-Carb'];
  
      preferences.forEach(preference => {
        const preferenceInput = document.createElement('input');
        preferenceInput.setAttribute('type', 'checkbox');
        preferenceInput.setAttribute('id', preference.toLowerCase());
        preferenceInput.classList.add('preference-checkbox');
  
        const preferenceLabel = document.createElement('label');
        preferenceLabel.setAttribute('for', preference.toLowerCase());
        preferenceLabel.textContent = preference;
  
        mealPreferencesContainer.appendChild(preferenceInput);
        mealPreferencesContainer.appendChild(preferenceLabel);
      });
    }
 
    addMealPreferences();
  });
  