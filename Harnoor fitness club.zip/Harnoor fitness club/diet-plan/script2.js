function trackNutrition() {
    const foodItem = document.getElementById('food-item').value;
    const calories = parseFloat(document.getElementById('calories').value);

    if (foodItem && !isNaN(calories)) {
        const nutritionLog = document.getElementById('nutrition-log');

      
        const nutritionEntry = {
            foodItem: foodItem,
            calories: calories,
        };

        const newItem = document.createElement('div');
        newItem.classList.add('nutrition-entry');
        newItem.innerHTML = `
            <strong>Food Item:</strong> ${nutritionEntry.foodItem}<br>
            <strong>Calories:</strong> ${nutritionEntry.calories.toFixed(2)}<br>
        `;

     
        nutritionLog.appendChild(newItem);

       
        calculateDailyTotal();
    }
}

function calculateDailyTotal() {
    const nutritionEntries = document.querySelectorAll('.nutrition-entry');
    let dailyTotal = 0;

    nutritionEntries.forEach(entry => {
        const calories = parseFloat(entry.querySelector('strong + strong').textContent);
        if (!isNaN(calories)) {
            dailyTotal += calories;
        }
    });

    const dailyTotalElement = document.getElementById('daily-total');
    dailyTotalElement.textContent = `Daily Total Calories: ${dailyTotal.toFixed(2)}`;
}

